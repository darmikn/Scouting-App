"""
============================================================================
robot.py - The Robot class (the original backend logic)
============================================================================
A Robot represents ONE team and remembers all of that team's match data.
It knows nothing about websites or files - it just stores numbers in lists
and does math on them. app.py creates one Robot per team and feeds it data.

The design uses "parallel lists": every match adds one item to each list, so
the data for match #3 is at position [2] in every list. For example:
    _auto_balls   = [3, 2, 4]   <- match 1 had 3, match 2 had 2, match 3 had 4
    _teleop_balls = [15, 12, 18]
============================================================================
"""


class Robot:
    def __init__(self, name):
        """Set up a brand-new Robot for one team.

        __init__ runs automatically when you write Robot("Team 1234").
        It creates the team name and seven empty lists to hold match data.
        The leading underscore (_) is a Python convention meaning "internal -
        please use the getter methods below instead of touching these directly."
        """
        self.name = name
        self._opp_robot = []        # who they played each match
        self._auto_balls = []       # balls scored in autonomous each match
        self._teleop_balls = []     # balls scored in teleop each match
        self._defense_rating = []   # defense rating (1-5) each match
        self._speed_rating = []     # speed rating (1-5) each match
        self._balls_passed = []     # balls passed to the other side each match
        self._climb_level = []      # climb level each match

    def add_match_data(self, opp, auto, tele, defense, speed, passed, climb):
        """Record one match. Adds one value to each of the seven lists.

        Because every list grows by exactly one item per call, the lists stay
        "in sync" - index [i] in every list belongs to the same match.
        """
        self._opp_robot.append(opp)
        self._auto_balls.append(auto)
        self._teleop_balls.append(tele)
        self._defense_rating.append(defense)
        self._speed_rating.append(speed)
        self._balls_passed.append(passed)
        self._climb_level.append(climb)

    # --- Getters: simple methods that hand back a piece of stored data ---
    # These let other code read the data without poking at the _lists directly.
    def get_name(self): return self.name
    def get_match_count(self): return len(self._opp_robot)   # how many matches
    def get_auto_balls(self): return self._auto_balls
    def get_teleop_balls(self): return self._teleop_balls
    def get_defense_ratings(self): return self._defense_rating
    def get_speed_ratings(self): return self._speed_rating
    def get_balls_passed(self): return self._balls_passed
    def get_climb_levels(self): return self._climb_level

    # --- Calculation helper ---
    def _calculate_avg(self, data_list):
        """Average of one list. Returns 0.0 for an empty list (no divide-by-zero)."""
        if not data_list:
            return 0.0
        return sum(data_list) / len(data_list)

    # --- Report: a human-readable text summary of averages ---
    def generate_report(self):
        """Build a multi-line text report of this team's average performance."""
        count = self.get_match_count()
        if count == 0:
            return f"No data available for {self.name}."

        # Compute every average up front and store in a small dict.
        report_data = {
            "Auto": self._calculate_avg(self._auto_balls),
            "Teleop": self._calculate_avg(self._teleop_balls),
            "Defense": self._calculate_avg(self._defense_rating),
            "Speed": self._calculate_avg(self._speed_rating),
            "Passes": self._calculate_avg(self._balls_passed),
            "Climb": self._calculate_avg(self._climb_level),
        }

        # Build the report line by line, then join with newlines.
        # The :.2f formatting shows each number with 2 decimal places.
        report = [
            f"=== OVERALL REPORT: {self.name} ===",
            f"Matches: {count}",
            "-" * 30,
            f"Avg Auto:    {report_data['Auto']:.2f}",
            f"Avg Teleop:  {report_data['Teleop']:.2f}",
            f"Avg Defense: {report_data['Defense']:.2f}/5",
            f"Avg Speed:   {report_data['Speed']:.2f}/5",
            f"Avg Passes:  {report_data['Passes']:.2f}",
            f"Avg Climb:   {report_data['Climb']:.2f}",
            "=" * 30
        ]
        return "\n".join(report)

    def __str__(self):
        """Define what str(robot) or print(robot) produces: a match-by-match list.

        __str__ is a special Python method - it runs whenever this object needs
        to be shown as text. Here it lists each match and its teleop balls.
        """
        header = f"--- Match History: {self.name} ---"
        count = self.get_match_count()
        if count == 0:
            return f"{header}\nNo matches recorded."

        lines = [header]
        for i in range(count):              # loop once per match
            lines.append(
                f"Match {i+1} vs {self._opp_robot[i]}: "
                f"{self._teleop_balls[i]} teleop balls"
            )
        return "\n".join(lines)
