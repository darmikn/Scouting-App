"""
============================================================================
FRC 2026 - Rebuilt Scout Tracker
============================================================================
This is the MAIN file. Think of it as the "waiter" in a restaurant: when a
browser asks for a page, the code here fetches the data, does the math, and
sends back a finished web page.

Tech used:
  - Flask        : the web framework (handles browser requests + responses)
  - CSV file     : where scouting data is saved (no database, no JSON)
  - Robot class  : the original backend logic, kept in robot.py
  - matplotlib   : draws the charts, kept in charts.py

How a page load works, every single time:
  browser asks for a page -> a function below runs -> it reads the CSV ->
  builds Robot objects -> calculates stats -> fills in an HTML template ->
  sends the page back to the browser.
============================================================================
"""

# ---- Imports: tools we borrow from Python and Flask ----
import csv                       # reads/writes CSV files (our data storage)
import os                        # works with file paths and folders
from collections import defaultdict  # a dict that auto-creates empty lists

# Flask pieces:
#   Flask          - the app itself
#   render_template- turns an HTML file in /templates into a real page
#   request        - holds whatever the browser sent us (form data, URL options)
#   redirect       - sends the browser to a different page
#   url_for        - looks up a page's URL by its function name
#   flash          - shows a one-time popup message ("Entry saved!")
from flask import Flask, render_template, request, redirect, url_for, flash

from robot import Robot          # the team-stats class (original backend)
import charts                    # our chart-drawing helpers (matplotlib)

# Create the application object. __name__ tells Flask where it lives.
app = Flask(__name__)
# A secret key is REQUIRED for flash() messages to work. It signs the cookie
# Flask uses to remember the message between page loads. Any string works.
app.secret_key = "frc-2026-scout-tracker"


# ===========================================================================
# SECTION 1: CSV STORAGE  (our "filing cabinet")
# ===========================================================================
# These functions are the only ones that touch the data file. Everything else
# in the app goes through them, so data handling lives in one place.

# Figure out WHERE the data file lives: a "data" folder sitting right next to
# this app.py file. Doing it this way means it works no matter which folder
# you launch the app from.
DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
CSV_FILE = os.path.join(DATA_DIR, "scouting_data.csv")

# The columns of the CSV, in order. EVERYTHING relies on this list, so if you
# add a new stat, add its column name here too.
CSV_HEADERS = [
    "match_num",
    "team",
    "auto_balls",
    "teleop_balls",
    "balls_passed",
    "defense_rating",
    "speed_rating",
    "climb_level",
]

# Valid range for each numeric field: (minimum, maximum).
# A maximum of None means "no upper limit" (ball counts can be any positive number).
# Used both when saving new entries and when cleaning existing ones.
FIELD_RANGES = {
    "auto_balls":     (0, None),
    "teleop_balls":   (0, None),
    "balls_passed":   (0, None),
    "defense_rating": (1, 5),
    "speed_rating":   (1, 5),
    "climb_level":    (0, 3),
}


def clamp(value, lo, hi):
    """Force a number to stay within [lo, hi]. e.g. clamp(70, 0, 3) -> 3."""
    if value < lo:
        return lo
    if hi is not None and value > hi:
        return hi
    return value



def ensure_csv():
    """Make sure the data folder and CSV file exist before we use them.

    If the file is missing, create it with just the header row. Called all
    over the app so a missing file never causes a crash.
    """
    os.makedirs(DATA_DIR, exist_ok=True)   # create /data folder if needed
    if not os.path.exists(CSV_FILE):       # only create the file if absent
        with open(CSV_FILE, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(CSV_HEADERS)   # write the column titles


def read_entries():
    """Read every row from the CSV and return them as a list of dictionaries.

    Example of one returned item:
        {"match_num": "1", "team": "Team 1234", "auto_balls": "3", ...}
    NOTE: every value is TEXT (a string), even numbers. "3" not 3.
    """
    ensure_csv()
    with open(CSV_FILE, "r", newline="") as f:
        # DictReader uses the header row as the dictionary keys automatically.
        return list(csv.DictReader(f))


def write_entries(entries):
    """Overwrite the ENTIRE file with a new list of entries.

    Used when we delete a row or remove duplicates - we rewrite what's left.
    """
    with open(CSV_FILE, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=CSV_HEADERS)
        writer.writeheader()               # re-write the column titles
        writer.writerows(entries)          # then all the data rows


def append_entry(entry):
    """Add ONE new row to the end of the file (used when the form is submitted).

    "a" mode means "append" - add to the end without erasing what's there.
    """
    ensure_csv()
    with open(CSV_FILE, "a", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=CSV_HEADERS)
        writer.writerow(entry)


# ===========================================================================
# SECTION 2: HELPERS  (turning raw rows into useful numbers)
# ===========================================================================

def safe_int(value, default=0):
    """Convert text like "3" into the number 3.

    The CSV gives us text, but math needs real numbers. If the value is empty
    or broken (can't be converted), we return 0 instead of crashing.
    """
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def build_robots():
    """Group all CSV rows by team, then build one Robot object per team.

    This is the bridge between the CSV (storage) and the Robot class (logic).
    The CSV just stores flat rows; this sorts them into per-team piles and
    feeds each pile into a Robot, which then does the averaging.
    """
    entries = read_entries()
    # defaultdict(list) means: if a team isn't in the dict yet, start it with
    # an empty list automatically (so we can just .append without checking).
    grouped = defaultdict(list)
    for e in entries:
        grouped[e["team"]].append(e)       # put each row in its team's pile

    robots = {}
    for team, rows in grouped.items():
        if not team:                       # skip rows with a blank team name
            continue
        robot = Robot(team)                # one Robot = one team
        for r in rows:
            # Feed each match into the Robot using the method from robot.py.
            # safe_int converts the text values into real numbers.
            robot.add_match_data(
                opp=f"Match {r['match_num']}",
                auto=safe_int(r["auto_balls"]),
                tele=safe_int(r["teleop_balls"]),
                defense=safe_int(r["defense_rating"]),
                speed=safe_int(r["speed_rating"]),
                passed=safe_int(r["balls_passed"]),
                climb=safe_int(r["climb_level"]),
            )
        robots[team] = robot
    return robots


def header_stats():
    """Small counts shown at the top-right of every page (entries / teams)."""
    entries = read_entries()
    # A set {} automatically removes duplicates, so this counts UNIQUE teams.
    teams = {e["team"] for e in entries if e["team"]}
    return {"entries": len(entries), "teams": len(teams)}


def admin_summary():
    """The three counts shown on the Admin tab's Data Summary box."""
    entries = read_entries()
    teams = {e["team"] for e in entries if e["team"]}
    matches = {e["match_num"] for e in entries if e["match_num"]}
    return {
        "total_entries": len(entries),
        "unique_teams": len(teams),
        "matches_tracked": len(matches),
    }


def avg(seq):
    """Average of a list of numbers, rounded to 2 decimals.

    The "if seq else 0.0" guard avoids dividing by zero on an empty list.
    """
    return round(sum(seq) / len(seq), 2) if seq else 0.0


def stddev(seq):
    """Standard deviation - how spread out a team's scores are.

    LOW number = scores are close together = consistent / reliable team.
    HIGH number = scores jump around a lot = unpredictable team.
    Needs at least 2 matches to mean anything, so we return 0 below that.
    """
    if len(seq) < 2:
        return 0.0
    m = sum(seq) / len(seq)                          # the mean (average)
    var = sum((x - m) ** 2 for x in seq) / len(seq)  # variance
    return round(var ** 0.5, 2)                      # std dev = sqrt(variance)


# ---------------------------------------------------------------------------
# Central list of all stats. Defined ONCE here, then reused by the filter
# chips, the table columns, the charts, and the rankings. Add a stat here and
# it shows up everywhere automatically.
#   Each tuple = (short_key, display_label, dict_field, max_value, higher_is_better)
# ---------------------------------------------------------------------------
STAT_REGISTRY = [
    ("auto",    "Avg Auto",    "avg_auto",    None, True),
    ("teleop",  "Avg Teleop",  "avg_teleop",  None, True),
    ("passes",  "Avg Passes",  "avg_passes",  None, True),
    ("defense", "Avg Defense", "avg_defense", 5,    True),
    ("speed",   "Avg Speed",   "avg_speed",   5,    True),
    ("climb",   "Avg Climb",   "avg_climb",   3,    True),
    ("total",   "Total Avg",   "total_avg",   None, True),
]
# Just the short keys on their own, handy for quick "is this valid?" checks.
STAT_KEYS = [s[0] for s in STAT_REGISTRY]


def build_reports():
    """Turn the Robot objects into a simple list of per-team dictionaries.

    This is the data the Data Analysis page actually displays. Each dict holds
    one team's name, match count, and all its pre-calculated averages.
    """
    robots = build_robots()
    reports = []
    for team, robot in robots.items():
        auto_avg = avg(robot.get_auto_balls())
        tele_avg = avg(robot.get_teleop_balls())
        reports.append(
            {
                "name": team,
                "matches": robot.get_match_count(),
                "avg_auto": auto_avg,
                "avg_teleop": tele_avg,
                "avg_defense": avg(robot.get_defense_ratings()),
                "avg_speed": avg(robot.get_speed_ratings()),
                "avg_passes": avg(robot.get_balls_passed()),
                "avg_climb": avg(robot.get_climb_levels()),
                "total_avg": round(auto_avg + tele_avg, 2),
                # consistency: steadiness of teleop scoring (lower = steadier)
                "consistency": stddev(robot.get_teleop_balls()),
            }
        )
    # Start sorted by total scoring, highest first.
    reports.sort(key=lambda r: r["total_avg"], reverse=True)
    return reports


def build_rankings(reports):
    """For EACH stat, rank teams best-to-worst and tag each with its place.

    Returns a dict like:
        {"teleop": [ {name, value, rank=1}, {name, value, rank=2}, ... ], ...}
    Used for the ranked charts, the "Best in Category" leaderboard, and the
    medal markers in the table.
    """
    rankings = {}
    for key, label, field, _max, _hib in STAT_REGISTRY:
        # Sort a copy of the teams by this stat, highest first.
        ordered = sorted(reports, key=lambda r: r[field], reverse=True)
        rankings[key] = [
            {"name": r["name"], "value": r[field], "rank": i + 1}
            for i, r in enumerate(ordered)   # enumerate gives us 0,1,2... -> rank
        ]
    return rankings


# ===========================================================================
# SECTION 3: ROUTES  (each function below = one web page or one action)
# ===========================================================================
# @app.route("/some/path") means "when the browser visits this path, run the
# function right below it." The function returns what the browser should show.

@app.route("/")
def index():
    """The home path "/" just bounces the user to the scouting form."""
    return redirect(url_for("scouting_form"))


@app.route("/scouting", methods=["GET", "POST"])
def scouting_form():
    """The Scouting Form page.

    GET  = someone is just viewing the form  -> show the empty form.
    POST = someone clicked Submit            -> save their entry, then reload.
    """
    if request.method == "POST":
        # request.form.get(name) reads a field the user filled in.
        team = request.form.get("team", "").strip()
        if not team:
            # No team name? Don't save. Show a red error and reload the form.
            flash("Team name / number is required.", "danger")
            return redirect(url_for("scouting_form"))

        # Build one CSV row from the submitted fields. The "or" parts supply a
        # default if a box was left blank.
        entry = {
            "match_num": request.form.get("match_num", "1").strip() or "1",
            "team": team,
            "auto_balls": request.form.get("auto_balls", "0") or "0",
            "teleop_balls": request.form.get("teleop_balls", "0") or "0",
            "balls_passed": request.form.get("balls_passed", "0") or "0",
            "defense_rating": request.form.get("defense_rating", "3"),
            "speed_rating": request.form.get("speed_rating", "3"),
            "climb_level": request.form.get("climb_level", "0"),
        }
        # Force every numeric field into its valid range so impossible values
        # (like a climb level of 70) can never get saved.
        for fld, (lo, hi) in FIELD_RANGES.items():
            entry[fld] = str(clamp(safe_int(entry[fld]), lo, hi))

        append_entry(entry)                # save it to the CSV
        flash(f"Entry saved for {entry['team']} (Match {entry['match_num']}).",
              "success")
        # Redirect (instead of just rendering) so a page refresh doesn't
        # accidentally submit the same entry twice.
        return redirect(url_for("scouting_form"))

    # If we get here it was a GET: just show the form.
    return render_template("scouting_form.html",
                           stats=header_stats(), active="form")


@app.route("/analysis")
def data_analysis():
    """The Data Analysis page: charts, rankings, and the sortable table."""
    reports = build_reports()

    # --- FILTER: which stats did the user choose to show? ---
    # The filter chips submit values like ?stat=teleop&stat=climb in the URL.
    # getlist() collects all of them into a list.
    selected = request.args.getlist("stat")
    if not selected:
        selected = list(STAT_KEYS)           # nothing chosen = show all
    # Keep only valid stat keys (ignore anything weird in the URL).
    selected = [s for s in selected if s in STAT_KEYS]

    # --- RANK BY: which single stat drives the big ranked chart + table sort? ---
    # Comes from the URL like ?rank_by=teleop. Defaults to total scoring.
    rank_by = request.args.get("rank_by", "total")
    if rank_by not in STAT_KEYS:
        rank_by = "total"
    # Look up the dictionary field that stat maps to (e.g. "teleop" -> "avg_teleop").
    rank_field = {k: f for k, _l, f, _m, _h in STAT_REGISTRY}[rank_by]
    rank_label = {k: lbl for k, lbl, f, _m, _h in STAT_REGISTRY}[rank_by]

    # Sort the table by the chosen stat, best (highest) first.
    if reports:
        reports = sorted(reports, key=lambda r: r[rank_field], reverse=True)

    rankings = build_rankings(reports)

    # --- CHARTS ---
    # The main chart is a ranking of every team by the chosen "rank_by" stat.
    # The other charts only draw if their stat is in the active filter.
    chart_imgs = {}
    if reports:
        chart_imgs["ranked"] = charts.chart_ranked_by_stat(reports, rank_field, rank_label)
        if "auto" in selected or "teleop" in selected:
            chart_imgs["points"] = charts.chart_avg_points(reports)
        if "defense" in selected or "speed" in selected:
            chart_imgs["ratings"] = charts.chart_ratings(reports)
        if "climb" in selected:
            chart_imgs["climb"] = charts.chart_climb(reports)
        chart_imgs["radar"] = charts.chart_radar(reports)

    # Hand all this data to the template, which arranges it into HTML.
    return render_template(
        "data_analysis.html",
        stats=header_stats(),
        summary=admin_summary(),
        reports=reports,
        rankings=rankings,
        charts=chart_imgs,
        stat_registry=STAT_REGISTRY,
        selected=selected,
        rank_by=rank_by,
        rank_label=rank_label,
        active="analysis",
    )


@app.route("/admin")
def admin():
    """The Admin page: data summary plus tools to clean up entries."""
    # enumerate() pairs each entry with its position number (0,1,2...). We pass
    # that number to the template so the delete button knows which row to remove.
    entries = list(enumerate(read_entries()))
    return render_template("admin.html",
                           stats=header_stats(),
                           summary=admin_summary(),
                           entries=entries,
                           active="admin")


@app.route("/admin/delete-entry", methods=["POST"])
def delete_entry():
    """Delete ONE entry, identified by its row number in the CSV."""
    # The form sends the row's index. Convert it to a number safely.
    try:
        idx = int(request.form.get("index", "-1"))
    except (TypeError, ValueError):
        idx = -1

    entries = read_entries()
    # Only delete if the index actually points at a real row.
    if 0 <= idx < len(entries):
        removed = entries.pop(idx)         # remove that row from the list
        write_entries(entries)             # save the shortened list back
        flash(f"Removed entry: {removed['team']} (Match {removed['match_num']}).",
              "warning")
    else:
        flash("Could not find that entry to remove.", "danger")
    return redirect(url_for("admin"))


@app.route("/admin/delete-all", methods=["POST"])
def delete_all():
    """Wipe ALL data by deleting the file, then recreating it empty."""
    if os.path.exists(CSV_FILE):
        os.remove(CSV_FILE)
    ensure_csv()                           # make a fresh empty file
    flash("All scouting data deleted.", "warning")
    return redirect(url_for("admin"))


@app.route("/admin/remove-duplicates", methods=["POST"])
def remove_duplicates():
    """Remove repeated entries that have the same team AND match number.

    Keeps the FIRST one seen for each team+match pair, drops the rest.
    """
    entries = read_entries()
    seen = set()                           # remembers which pairs we've kept
    unique = []
    for e in entries:
        key = (e["team"], e["match_num"])  # a team+match pair
        if key in seen:
            continue                       # already kept one - skip this dup
        seen.add(key)
        unique.append(e)
    removed = len(entries) - len(unique)
    write_entries(unique)
    flash(f"Removed {removed} duplicate {'entry' if removed == 1 else 'entries'}.",
          "info")
    return redirect(url_for("admin"))


@app.route("/admin/fix-ranges", methods=["POST"])
def fix_ranges():
    """Clean existing entries by clamping any out-of-range numbers.

    Keeps every row - it only corrects impossible values (e.g. a climb level of
    70 becomes 3, a defense rating of 0 becomes 1). Counts how many cells it had
    to fix so the user gets feedback.
    """
    entries = read_entries()
    fixed_cells = 0
    fixed_rows = 0
    for e in entries:
        row_changed = False
        for fld, (lo, hi) in FIELD_RANGES.items():
            original = e.get(fld, "")
            corrected = clamp(safe_int(original), lo, hi)
            if str(corrected) != str(original):
                e[fld] = str(corrected)
                fixed_cells += 1
                row_changed = True
        if row_changed:
            fixed_rows += 1
    write_entries(entries)
    if fixed_cells:
        flash(f"Corrected {fixed_cells} out-of-range "
              f"{'value' if fixed_cells == 1 else 'values'} "
              f"across {fixed_rows} {'entry' if fixed_rows == 1 else 'entries'}.",
              "info")
    else:
        flash("No out-of-range values found - all data is already valid.",
              "success")
    return redirect(url_for("admin"))


@app.route("/team/<team>")
def team_detail(team):
    """A single team's detail page.

    The <team> part of the path is a variable - visiting /team/Team%201234
    passes "Team 1234" in as the `team` argument. This page shows the text
    report from your Robot class plus a scoring-over-time chart.
    """
    robots = build_robots()
    robot = robots.get(team)               # find the Robot for this team
    if not robot:
        flash(f"No data for {team}.", "danger")
        return redirect(url_for("data_analysis"))
    return render_template(
        "team_detail.html",
        stats=header_stats(),
        robot=robot,
        report_text=robot.generate_report(),   # the text report (your method)
        history_text=str(robot),                # the __str__ output (your method)
        progression_chart=charts.chart_team_progression(robot),
        active="analysis",
    )


# ===========================================================================
# SECTION 4: START THE APP
# ===========================================================================
# This block only runs when you launch the file directly with "python app.py"
# (not when another file imports it). It starts Flask's built-in web server.
if __name__ == "__main__":
    ensure_csv()                           # make sure the data file exists
    # debug=True   -> auto-reloads on code changes and shows error details
    # host=0.0.0.0 -> reachable from other devices on the same network
    # port=5001    -> the address is http://localhost:5001
    #                 (using 5001 instead of 5000, which macOS AirPlay often uses)
    app.run(debug=True, host="0.0.0.0", port=5001)
