# FRC 2026 — Rebuilt Scout Tracker

Flask + Bootstrap + CSV scouting app with matplotlib data visualization.
The `Robot` class from the original backend is reused as-is.

## Stack
- **Backend**: Flask, the original `Robot` class
- **Storage**: CSV (`data/scouting_data.csv`) — no JSON
- **Charts**: matplotlib, rendered server-side as embedded PNGs
- **Frontend**: Bootstrap 5 (CDN) + custom dark/cyan theme

## Run

```bash
pip install -r requirements.txt
python app.py
```

Open http://localhost:5000  (or whatever port you set at the bottom of app.py).
On macOS, port 5000 is often taken by AirPlay — change `port=5000` to `port=5001`.

## Pages

### Scouting Form
Match entry: autonomous balls, teleop balls, passed balls, defense / speed / climb ratings.

### Data Analysis
- **Rank teams by** — pick any stat and every team is ranked best-to-worst for it,
  in both the main chart (gold/silver/bronze podium) and the table.
- **Show stats filter** — toggle which stats appear in the charts and table (click the chips).
- **Radar comparison** — top 4 teams (by total scoring) overlaid across all stats at once.
- **Best in Each Category** leaderboard — the #1 team for each individual stat.
- **Filtered charts** — average balls scored (stacked auto+teleop), defense/speed ratings, climb.
- **Ranked table** — numbered 1,2,3... with medals for the podium. Click any stat header to
  re-rank by it. Category leaders get a ★, and a consistency column shows teleop variation
  (lower = steadier).
- Click a team name to open its detail page (full report + scoring-over-time line chart).

### Admin
Data summary, delete-all, remove-duplicates.


## File layout
```
frc_scouting/
├── app.py                 Flask routes, CSV helpers, rankings
├── robot.py               The Robot class (unchanged)
├── charts.py              matplotlib chart generators
├── requirements.txt
├── data/
│   └── scouting_data.csv  Auto-created on first run
├── static/css/style.css   Dark / cyan theme
└── templates/
    ├── base.html
    ├── scouting_form.html
    ├── data_analysis.html
    ├── admin.html
    └── team_detail.html
```
