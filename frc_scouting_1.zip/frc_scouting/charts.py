"""
============================================================================
charts.py - Draws all the graphs using matplotlib
============================================================================
Instead of saving chart images as files on disk, each function here draws a
chart and converts it into a long text string (base64) that can be pasted
straight into an HTML <img> tag. That means no image files to manage and
nothing to clean up - the chart travels with the page.

Every function takes the `reports` list (the per-team data built in app.py)
and returns one of these base64 image strings.
============================================================================
"""
import base64   # turns the raw image bytes into safe text for HTML
import io       # lets us "save" the image into memory instead of a file

import matplotlib
# "Agg" is a backend that draws images without needing a screen/window.
# Required because this runs on a web server with no display attached.
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ---- Theme colors, matching the dark/cyan look of the rest of the app ----
BG = "#0d1424"        # background (dark navy)
ACCENT = "#22d3ee"    # main cyan
ACCENT_2 = "#0891b2"  # darker cyan
ACCENT_3 = "#7c5cff"  # purple (second series)
TEXT = "#e2e8f0"      # light text
MUTED = "#64748b"     # gray for less-important labels
GRID = "#1a2540"      # faint grid lines

# rcParams = matplotlib's global default settings. Setting them once here
# means every chart automatically uses the dark theme without repeating it.
plt.rcParams.update({
    "figure.facecolor": BG,
    "axes.facecolor": BG,
    "savefig.facecolor": BG,
    "text.color": TEXT,
    "axes.labelcolor": TEXT,
    "xtick.color": MUTED,
    "ytick.color": MUTED,
    "axes.edgecolor": GRID,
    "axes.grid": True,
    "grid.color": GRID,
    "grid.linewidth": 0.6,
    "font.family": "monospace",
    "font.size": 10,
})


def _fig_to_base64(fig):
    """Convert a finished matplotlib figure into a base64 image string.

    Steps: save the image into an in-memory buffer (not a file) -> close the
    figure to free memory -> encode the bytes as base64 text -> return it with
    the "data:image/png;base64," prefix that an HTML <img> tag understands.
    The leading underscore marks this as an internal helper.
    """
    buf = io.BytesIO()                  # a fake "file" that lives in memory
    fig.savefig(buf, format="png", dpi=110, bbox_inches="tight")
    plt.close(fig)                      # free the figure so memory doesn't pile up
    buf.seek(0)                         # rewind to the start of the buffer
    encoded = base64.b64encode(buf.read()).decode("ascii")
    return f"data:image/png;base64,{encoded}"


def _no_data_chart(message="No data yet"):
    """A blank placeholder chart shown when there's nothing to plot yet."""
    fig, ax = plt.subplots(figsize=(7, 3))
    ax.text(0.5, 0.5, message, ha="center", va="center",
            color=MUTED, fontsize=12)   # centered gray message
    ax.set_axis_off()                   # hide the empty axes
    return _fig_to_base64(fig)


def chart_avg_points(reports):
    """Stacked bar: average auto + teleop balls per team (the scoring chart).

    Each team gets one bar. The bar has two stacked parts: auto on the bottom,
    teleop on top, so the full bar height = total average scoring.
    """
    if not reports:
        return _no_data_chart()

    # Pull three matching lists out of the reports: names, autos, teleops.
    names = [r["name"] for r in reports]
    auto = [r["avg_auto"] for r in reports]
    teleop = [r["avg_teleop"] for r in reports]

    fig, ax = plt.subplots(figsize=(8, 4.2))   # create the canvas
    x = range(len(names))                      # bar positions: 0,1,2,...
    # First layer: auto balls.
    ax.bar(x, auto, label="Auto", color=ACCENT_2, edgecolor=ACCENT, linewidth=0.6)
    # Second layer: teleop, stacked on top using bottom=auto.
    ax.bar(x, teleop, bottom=auto, label="Teleop", color=ACCENT,
           edgecolor="#0a1120", linewidth=0.6)

    # Write the total number just above each bar.
    for i, (a, t) in enumerate(zip(auto, teleop)):
        ax.text(i, a + t + 0.3, f"{a + t:.1f}", ha="center", va="bottom",
                color=TEXT, fontsize=9)

    ax.set_xticks(list(x))
    ax.set_xticklabels(names, rotation=20, ha="right")  # tilt names so they fit
    ax.set_ylabel("Avg balls scored")
    ax.set_title("Average Balls Scored per Team", color=ACCENT, pad=12)
    ax.legend(facecolor=BG, edgecolor=GRID, labelcolor=TEXT)
    ax.grid(axis="x", visible=False)           # vertical grid lines off
    return _fig_to_base64(fig)


def chart_ratings(reports):
    """Grouped bar: defense vs speed rating side by side for each team.

    Unlike the stacked chart above, here the two bars sit NEXT to each other
    (one shifted left, one shifted right) so you can compare them directly.
    """
    if not reports:
        return _no_data_chart()

    names = [r["name"] for r in reports]
    defense = [r["avg_defense"] for r in reports]
    speed = [r["avg_speed"] for r in reports]

    fig, ax = plt.subplots(figsize=(8, 4.2))
    x = range(len(names))
    width = 0.38                               # how wide each bar is
    # Shift defense bars half a width left, speed bars half a width right.
    ax.bar([i - width / 2 for i in x], defense, width=width,
           label="Defense", color=ACCENT_3, edgecolor="#0a1120", linewidth=0.6)
    ax.bar([i + width / 2 for i in x], speed, width=width,
           label="Speed", color=ACCENT, edgecolor="#0a1120", linewidth=0.6)

    ax.set_xticks(list(x))
    ax.set_xticklabels(names, rotation=20, ha="right")
    ax.set_ylabel("Avg rating (out of 5)")
    ax.set_ylim(0, 5.5)                         # ratings max out at 5
    ax.set_title("Average Defense & Speed Ratings", color=ACCENT, pad=12)
    ax.legend(facecolor=BG, edgecolor=GRID, labelcolor=TEXT)
    ax.grid(axis="x", visible=False)
    return _fig_to_base64(fig)


def chart_climb(reports):
    """Horizontal bar: average climb level per team (bars go sideways)."""
    if not reports:
        return _no_data_chart()

    names = [r["name"] for r in reports]
    climb = [r["avg_climb"] for r in reports]

    fig, ax = plt.subplots(figsize=(8, 3.6))
    y = range(len(names))
    ax.barh(list(y), climb, color=ACCENT, edgecolor="#0a1120", linewidth=0.6)  # barh = horizontal
    for i, c in enumerate(climb):              # write each value at the bar's end
        ax.text(c + 0.05, i, f"{c:.1f}", va="center", color=TEXT, fontsize=9)

    ax.set_yticks(list(y))
    ax.set_yticklabels(names)
    ax.set_xlabel("Avg climb level")
    ax.set_xlim(0, 3.4)                         # climb maxes at 3
    ax.set_title("Average Climb Level", color=ACCENT, pad=12)
    ax.grid(axis="y", visible=False)
    ax.invert_yaxis()                          # put the first team at the top
    return _fig_to_base64(fig)


def chart_ranked_by_stat(reports, field, label):
    """Horizontal bar ranking every team by ONE chosen stat, best at the top.

    This is the main chart and it changes based on the "Rank by" selector.
    Medal colors highlight the podium: gold #1, silver #2, bronze #3.
    `field` is the dict key to read (e.g. "avg_teleop"); `label` is its title.
    """
    if not reports:
        return _no_data_chart()

    # Sort teams by the chosen stat, highest first.
    ordered = sorted(reports, key=lambda r: r[field], reverse=True)
    names = [r["name"] for r in ordered]
    values = [r[field] for r in ordered]

    # Podium colors for the top 3, muted blue for everyone else.
    gold, silver, bronze = "#fbbf24", "#cbd5e1", "#d97706"
    n = len(names)
    colors = []
    for i in range(n):
        if i == 0:
            colors.append(gold)
        elif i == 1:
            colors.append(silver)
        elif i == 2:
            colors.append(bronze)
        else:
            colors.append(ACCENT)

    # Taller canvas when there are more teams so bars don't get cramped.
    fig, ax = plt.subplots(figsize=(8, max(3.2, 0.55 * n + 1.5)))
    y = range(n)
    ax.barh(list(y), values, color=colors, edgecolor="#0a1120", linewidth=0.6)
    # Write each value at the end of its bar, with a medal for the top 3.
    medals = {0: "  #1", 1: "  #2", 2: "  #3"}
    for i, v in enumerate(values):
        tag = medals.get(i, "")
        ax.text(v + (max(values) * 0.01 + 0.05), i, f"{v:.2f}{tag}",
                va="center", color=TEXT, fontsize=9)

    ax.set_yticks(list(y))
    ax.set_yticklabels(names)
    ax.set_xlabel(label)
    # A little headroom on the right so the labels fit.
    ax.set_xlim(0, (max(values) if values else 1) * 1.18 or 1)
    ax.set_title(f"Teams Ranked by {label}", color=ACCENT, pad=12)
    ax.grid(axis="y", visible=False)
    ax.invert_yaxis()                    # best team at the top
    return _fig_to_base64(fig)


def chart_radar(reports, top_n=4):
    """Radar (spider) chart comparing the top N teams across all stats at once.

    A radar chart has one spoke per stat arranged in a circle. Each team becomes
    a colored shape; the bigger the shape, the stronger the team overall. Great
    for spotting all-rounders vs specialists at a glance.

    All values are normalized to 0-1 (each divided by the best team's value for
    that stat) so different scales - balls vs 1-5 ratings - sit on one circle.
    """
    import math                          # needed for the circle angle math
    if not reports:
        return _no_data_chart()

    # Take only the top N teams by total scoring (auto + teleop).
    ordered = sorted(reports, key=lambda r: r.get("total_avg", 0), reverse=True)[:top_n]

    # The six spokes: (label shown, which field to read).
    axes_def = [
        ("Auto", "avg_auto"),
        ("Teleop", "avg_teleop"),
        ("Passes", "avg_passes"),
        ("Defense", "avg_defense"),
        ("Speed", "avg_speed"),
        ("Climb", "avg_climb"),
    ]
    # Best value per stat across ALL teams, used to scale everyone to 0-1.
    maxes = {f: max((r[f] for r in reports), default=0) or 1 for _l, f in axes_def}

    labels = [l for l, _f in axes_def]
    num_vars = len(labels)               # 6 spokes
    # Evenly space the spokes around a full circle (2*pi radians).
    angles = [n / float(num_vars) * 2 * math.pi for n in range(num_vars)]
    angles += angles[:1]                 # repeat the first angle to close the shape

    # subplot_kw=dict(polar=True) makes this a circular plot instead of square.
    fig, ax = plt.subplots(figsize=(6.5, 6.5), subplot_kw=dict(polar=True))
    palette = [ACCENT, ACCENT_3, "#f59e0b", "#10b981"]   # up to 4 team colors

    for idx, r in enumerate(ordered):
        # This team's value on each spoke, scaled to 0-1.
        vals = [r[f] / maxes[f] for _l, f in axes_def]
        vals += vals[:1]                 # close the loop back to the start
        color = palette[idx % len(palette)]   # % wraps around if >4 teams
        ax.plot(angles, vals, color=color, linewidth=2, label=r["name"])  # outline
        ax.fill(angles, vals, color=color, alpha=0.12)                    # faint fill

    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(labels, color=TEXT, fontsize=10)
    ax.set_yticks([0.25, 0.5, 0.75, 1.0])
    ax.set_yticklabels(["", "", "", ""], color=MUTED)   # hide the ring numbers
    ax.set_ylim(0, 1)
    ax.spines["polar"].set_color(GRID)
    ax.grid(color=GRID)
    ax.set_facecolor(BG)
    ax.set_title("Top Teams - Multi-Stat Comparison", color=ACCENT, pad=24)
    ax.legend(loc="upper right", bbox_to_anchor=(1.25, 1.1),
              facecolor=BG, edgecolor=GRID, labelcolor=TEXT, fontsize=9)
    return _fig_to_base64(fig)


def chart_team_progression(robot):
    """Line chart of one team's auto + teleop balls across its matches.

    Shown on the team detail page. Two lines - teleop (circles) and auto
    (squares) - track how a single team's scoring changes match to match.
    Note this takes a Robot object directly, not the reports list.
    """
    auto = robot.get_auto_balls()
    teleop = robot.get_teleop_balls()
    if not teleop:
        return _no_data_chart("No matches recorded")

    matches = list(range(1, len(teleop) + 1))   # x-axis: match 1, 2, 3, ...
    fig, ax = plt.subplots(figsize=(8, 3.8))
    ax.plot(matches, teleop, marker="o", color=ACCENT, linewidth=2,
            label="Teleop", markerfacecolor=ACCENT, markeredgecolor="#0a1120")
    ax.plot(matches, auto, marker="s", color=ACCENT_3, linewidth=2,
            label="Auto", markerfacecolor=ACCENT_3, markeredgecolor="#0a1120")

    ax.set_xticks(matches)
    ax.set_xlabel("Match")
    ax.set_ylabel("Balls scored")
    ax.set_title(f"Scoring Over Time — {robot.get_name()}", color=ACCENT, pad=12)
    ax.legend(facecolor=BG, edgecolor=GRID, labelcolor=TEXT)
    return _fig_to_base64(fig)
